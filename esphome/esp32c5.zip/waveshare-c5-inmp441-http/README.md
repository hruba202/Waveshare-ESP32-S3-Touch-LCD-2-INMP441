# Waveshare ESP32-C5-WIFI6-KIT-N16R8 + INMP441



## Zapojení



| INMP441 | Označení pinu na C5 desce |
|---|---|
| VDD / VCC | 3V3 |
| GND | GND |
| SCK / BCLK | 8 (GPIO8) |
| WS / LRCLK | 9 (GPIO9) |
| SD | 10 (GPIO10) |
| L/R | GND – levý kanál |

Při pohledu na součástky s anténou nahoře a USB dole jsou 8, 9 a 10
na levé řadě konektoru. Řiď se popisky GPIO, nikoli počítáním kontaktů.
Napájení mikrofonu je 3,3 V; nepoužívej 5V ani VBAT.
Zapojování dělej s odpojeným USB i baterií.





## Příprava v ESPHome

1. Rozbal celý balíček do jedné složky v ESPHome, včetně `components/`.
2. Zachovej svůj `secrets.yaml`, nebo ho vytvoř podle `secrets.example.yaml`.
   Doplň Wi-Fi, API klíč `esp_encryption_key`, OTA heslo, nový náhodný token
   a skutečnou podsíť HA/PC v `audio_allowed_subnet`, např. `192.168.0.0/24`.
   Tajné údaje nepatří do chatu ani GitHubu. API klíč je base64 32 bajtů;
   token je samostatný URL-safe řetězec o délce 32–128 znaků.
3. Použij ESPHome 2026.10.0; projekt připíná ESP-IDF 5.5.6.

```sh
esphome config microphone-c5.yaml
esphome compile microphone-c5.yaml
```


## Test zvuku

1. V HA zapni **Microphone Stream**. Po restartu je vždy OFF.
2. Zisk **Microphone Gain** nech nejdřív na 1.
3. Z PC spusť v terminálu (nikoli ve vyhledávání prohlížeče):


```sh
ffplay -nodisp "http://IP_DESKY:8081/audio.wav?token=TVUJ_TOKEN"
```


**OVĚŘENO ze zdrojů komponenty:** jeden zvukový klient, token, kontrola LAN
podsítě, neblokující fronta, vypnutí při ztrátě Wi-Fi, žádný zápis audia.
Bez klienta se mikrofon nespouští. Vypnutý stream nechává Wi-Fi/HA dostupné;
nejde o hluboký spánek ani odpojení napájení mikrofonu.
Stav přenosu ukazuje HA entita **Microphone Sending**; deska nemá LCD
a firmware zatím neovládá palubní RGB LED.

403 = nesprávná podsíť, 401 = token, 409 = obsazený klient, 503 = vypnutý stream.
Pouze důvěryhodná LAN, žádné veřejné přesměrování portu. HTTP není šifrované.
Token generuj lokálně např.:

```sh
python -c "import secrets; print(secrets.token_urlsafe(32))"
```



## Baterie
 deska má nabíjecí obvod a MX1.25 konektor pro jednu
lithiovou baterii 3,7 V. Před připojením ověř polaritu konkrétního kabelu
a baterie; mikrofon se i při bateriovém provozu napájí z 3V3.

# Waveshare ESP32-C5-WIFI6-KIT-N16R8 + INMP441



## Wiring



| INMP441 | Pin Label on C5 Board |
|---|---|
| VDD / VCC | 3V3 |
| GND | GND |
| SCK / BCLK | 8 (GPIO8) |
| WS / LRCLK | 9 (GPIO9) |
| SD | 10 (GPIO10) |
| L/R | GND – Left Channel |

When looking at the board with the antenna at the top and the USB port at the bottom, pins 8, 9, and 10 are located on the left-hand row of the connector. Follow the GPIO labels, rather than counting the pins.
The microphone requires a 3.3V power supply; do not use 5V or VBAT.
Perform the wiring while both the USB cable and the battery are disconnected.


## Setup in ESPHome

1. Extract the entire package into a single folder within ESPHome, including the `components/` directory.
2. Keep your existing `secrets.yaml` file, or create one based on `secrets.example.yaml`.
   Fill in your Wi-Fi credentials, the `esp_encryption_key` (API key), an OTA password, a new random token,
   and the actual subnet for your HA/PC in `audio_allowed_subnet` (e.g., `192.168.0.0/24`).
   Never share sensitive credentials in chats or on GitHub. The API key must be a 32-byte Base64-encoded string;
   the token should be a unique, URL-safe string between 32 and 128 characters long.
3. Use ESPHome 2026.10.0; this project pins the ESP-IDF version to 5.5.6.

```sh
esphome config microphone-c5.yaml
esphome compile microphone-c5.yaml
```


## Audio Test

1. Enable **Microphone Stream** in Home Assistant (HA). Note that it defaults to OFF after a restart.
2. Initially, set the **Microphone Gain** to 1.
3. From your PC, run the following command in a terminal (do not enter it into a browser address bar):


```sh
ffplay -nodisp "http://BOARD_IP:8081/audio.wav?token=YOUR_TOKEN"
```
**VERIFIED via component sources:** single audio client, token, LAN subnet
check, non-blocking queue, shutdown upon Wi-Fi loss, no audio recording.
The microphone does not activate without a client. When the stream is disabled,
Wi-Fi/HA connectivity remains active; this is neither a deep sleep state nor
a power disconnection for the microphone.
The transmission status is indicated by the HA entity **Microphone Sending**;
the board lacks an LCD, and the firmware does not yet control the onboard RGB LED.

403 = incorrect subnet, 401 = token, 409 = client occupied, 503 = stream disabled.
Trusted LAN only; no public port forwarding. HTTP is unencrypted.
Generate the token locally, for example:

```sh
python -c "import secrets; print(secrets.token_urlsafe(32))"
```



## Battery
The board features a charging circuit and an MX1.25 connector for a single
3.7V lithium battery. Verify the polarity of the specific cable and battery
before connection; even when running on battery power, the microphone
is powered via the 3V3 rail.